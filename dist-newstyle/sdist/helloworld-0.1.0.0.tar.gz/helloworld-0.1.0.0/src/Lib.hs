module Lib
    ( someFunc
    ) where

someFunc :: IO ()
someFunc = putStrLn "my name is dima)))) yewssssssss!!!!!!!!!!!"
